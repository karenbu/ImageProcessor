﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace wpf_image_unit_test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Transform_Is_Valid(string TransformType)
        {
                Assert.Equals(TransformType,"Greyscale"); // stub - need to replace with better tests
        }
    }
}
