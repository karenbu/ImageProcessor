﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace wpf_image_processor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSelectImageFiles_Click(object sender, RoutedEventArgs e)
        {

            Microsoft.Win32.OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

            bool? response = openFileDialog.ShowDialog();

            if (response == true)
            {
                string filepath = openFileDialog.FileName;
                Image newImage = new Image();
                newImage.Source = new BitmapImage(new Uri(@"pack://application:,,,/wpf_image_processor;component/Images/product.png"));

                lstThumbnails.Items.Add(newImage.Source);
            }

        }

        private void lstThumbnails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //.net CachedBitmap -- to do: investigate this and other forms of caching, including NuGet CachedImage 

            originalImage.Source = new BitmapImage(new Uri(@"pack://application:,,,/wpf_image_processor;component/Images/map.png"));

            greyscaleImage.Source = new BitmapImage(new Uri(@"pack://application:,,,/wpf_image_processor;component/Images/map.png"));

        }
        /*private BitmapImage ConvertToGreyscale (originalImage)
        {
            throw new NotImplementedException();
        }*/
    }
}
